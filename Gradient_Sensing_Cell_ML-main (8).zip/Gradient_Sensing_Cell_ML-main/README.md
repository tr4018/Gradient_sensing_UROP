# Gradient_Sensing_Cell_ML
ML set up to imitate a cell that can sense a gradient of cue molecules and follow the gradient
